
Welcome to pandastable documentation.
=======================================

Contents:

.. toctree::
   :maxdepth: 2

.. automodule:: pandastable.core
    :members:

.. automodule:: pandastable.headers
    :members:

.. automodule:: pandastable.plotting
    :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

